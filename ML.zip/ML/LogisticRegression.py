#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np 
import pandas as pd 
import matplotlib.pyplot as plt
import seaborn as sns


# In[2]:


df = pd.read_csv("heart.csv")
df.sample(5)


# In[3]:


X=df.iloc[:, 0:13]
X.head()


# In[4]:


y=df.iloc[:,-1]
y.head()


# In[5]:


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
scaler.fit(X)
X = scaler.transform(X)


# In[6]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[7]:


from sklearn.linear_model import LogisticRegression
from sklearn import metrics


# In[8]:


logreg = LogisticRegression()
logreg.fit(X_train, y_train)


# In[9]:


y_pred = logreg.predict(X_test)


# In[10]:


print('Accuracy Score:')
print(metrics.accuracy_score(y_test,y_pred))


# In[11]:


from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
f,ax = plt.subplots(figsize=(10, 10))
sns.heatmap(cm, annot=True, linewidths=0.5,linecolor="red", fmt= '.0f',ax=ax)
plt.show()


# In[ ]:




