#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np # linear algebra
import pandas as pd
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import seaborn as sns


# In[5]:


df = pd.read_csv('Dataset_spine.csv')


# In[6]:


df = df.drop(['Unnamed: 13'], axis=1)


# In[7]:


df.head()


# In[8]:


df = df.drop(['Col7','Col8','Col9','Col10','Col11','Col12'], axis=1)


# In[9]:


df.head()


# In[10]:


from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix


# In[11]:


y = df['Class_att']
x = df.drop(['Class_att'], axis=1)


# In[12]:


x_train, x_test, y_train, y_test = train_test_split(x,y, test_size= 0.25, random_state=27)


# In[13]:


clf = MLPClassifier(hidden_layer_sizes=(100,100,100), max_iter=500, alpha=0.0001,
                     solver='sgd', verbose=10,  random_state=21,tol=0.000000001)


# In[14]:


clf.fit(x_train, y_train)
y_pred = clf.predict(x_test)



# In[15]:


accuracy_score(y_test, y_pred)


# In[16]:


cm = confusion_matrix(y_test, y_pred)
cm


# In[17]:


sns.heatmap(cm, center=True)
plt.show()


# In[ ]:




