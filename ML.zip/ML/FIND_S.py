#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
df = pd.read_csv('weather.csv')

print(df) 


# In[2]:


dict_data = df.to_dict(orient="records")
dict_data


# In[3]:


hypo=[]
for row in dict_data:
    if row['goes']=="yes":
        hypo.append(row)
        break
hypo


# In[4]:


temp={}
n=0


# In[5]:


for r in dict_data:
    if r['goes']=="yes":
        for col in r:
            if r[col]==hypo[n][col]:
                temp[col]=r[col]
            else:
                temp[col]='?'
        n+=1
        hypo.append(temp)
     


# In[6]:


print(hypo[-1])

