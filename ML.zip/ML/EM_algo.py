#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as nm    
import matplotlib.pyplot as mtp    
import pandas as pd 


# In[2]:


dataset = pd.read_csv('Mall_Customers.csv')  


# In[3]:


dataset.head()


# In[4]:


x = dataset.iloc[:, [3, 4]].values  


# In[5]:


from sklearn.mixture import GaussianMixture


# In[6]:


gm = GaussianMixture(n_components=5)


# In[7]:


y_predict=gm.fit_predict(x)


# In[8]:


mtp.scatter(x[y_predict == 0, 0], x[y_predict == 0, 1], s = 100, c = 'blue', label = 'Cluster 1') #for first cluster  
mtp.scatter(x[y_predict == 1, 0], x[y_predict == 1, 1], s = 100, c = 'green', label = 'Cluster 2') #for second cluster
mtp.scatter(x[y_predict== 2, 0], x[y_predict == 2, 1], s = 100, c = 'red', label = 'Cluster 3') #for third cluster
mtp.scatter(x[y_predict == 3, 0], x[y_predict == 3, 1], s = 100, c = 'cyan', label = 'Cluster 4') #for fourth cluster  
mtp.scatter(x[y_predict == 4, 0], x[y_predict == 4, 1], s = 100, c = 'magenta', label = 'Cluster 5') #for fifth cluster
mtp.title('Clusters of customers')  
mtp.xlabel('Annual Income (k$)')  
mtp.ylabel('Spending Score (1-100)')  
mtp.legend()  
mtp.show() 


# In[ ]:





# In[ ]:





# In[ ]:




