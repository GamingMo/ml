#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd

# importing matplotlib module 
from matplotlib import pyplot as plt
import matplotlib.pyplot as plt
from sklearn import linear_model
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error,r2_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report


# In[2]:


Dataset=pd.read_csv('satgpa.csv')
print(Dataset)


# In[3]:


x=Dataset.iloc[:,:1]
y=Dataset.iloc[:,-1]
print("Independent Variable is:\n",x)
print("Dependent variable is:\n",y)


# In[4]:


x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.4, random_state=4)
lm = linear_model.LinearRegression()
model = lm.fit(x_train,y_train)
print(model)


# In[5]:


y_pred = model.predict(x_test)
print(y_test)
print("y_prediction")
print(y_pred)


# In[6]:


plt.scatter(x_test,y_test, color='g', linewidth = 2,  label = 'line_1')
plt.plot(x_test,y_pred, color='r', linewidth = 2,  label = 'line_1')
plt.show()


# In[7]:


print('\n Coefficients : \n', model.coef_)
print('Mean Squared Error : %.2f' % mean_squared_error(y_test, y_pred))
print('Coefficient of determination : %.2f' % r2_score(y_test,y_pred))

